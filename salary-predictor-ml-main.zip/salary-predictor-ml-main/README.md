# salary-predictor-ml
Predicts salary using Python &amp; Machine Learning
